"""Flask + Flask-SocketIO entry point for the multiplayer Scrabble game.

The server is the single source of truth: clients only send *intents*
(place or stage tiles, submit, pass, change settings, ...) and the server answers with per-player state
views (a full snapshot on join, then diffs on every mutation).

Run locally:   python app.py
Production:    gunicorn -c gunicorn.conf.py -k eventlet -w 1 app:app
"""
import os

# eventlet must be monkey-patched before anything else is imported.  If it is
# not installed we fall back to Flask-SocketIO's threading mode so that
# `python app.py` still works for quick local experiments.
try:
    import eventlet

    eventlet.monkey_patch()
    ASYNC_MODE = "eventlet"
except ImportError:  # pragma: no cover - depends on the local environment
    ASYNC_MODE = "threading"

import logging
from functools import wraps

from flask import Flask, jsonify, render_template, request
from flask_socketio import SocketIO, join_room
from werkzeug.middleware.proxy_fix import ProxyFix

from game.board import GameError
from game.room import (
    CONFIG, DEFAULT_LENGTH, DEFAULT_MODE, LENGTHS, MAX_PLAYERS, MODES, TIMERS, RoomRegistry, available_languages, check_capacity,
    check_expand_margin, check_language, check_players, diff_views, length_for_players,
)

log = logging.getLogger("scrabble")

app = Flask(__name__)
# Railway / Render terminate TLS in front of us; trust one proxy hop so that
# request.host_url (used for the shareable link) has the right scheme and host.
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)


def _cors_origins():
    """CORS_ALLOWED_ORIGINS: unset = same origin only, '*' = anyone, or a comma list."""
    raw = os.environ.get("CORS_ALLOWED_ORIGINS", "").strip()
    if not raw:
        return None
    if raw == "*":
        return "*"
    return [o.strip() for o in raw.split(",") if o.strip()]


socketio = SocketIO(
    app,
    async_mode=ASYNC_MODE,
    cors_allowed_origins=_cors_origins(),
    max_http_buffer_size=64 * 1024,  # clients only ever send tiny JSON messages
    ping_interval=20,
    ping_timeout=30,
)

REGISTRY = RoomRegistry()

# socket id -> (room code, player token).  A player's token survives
# reconnects; the socket id does not.
SESSIONS = {}


# --------------------------------------------------------------------------
# HTTP routes
# --------------------------------------------------------------------------
@app.get("/")
def index():
    return render_template("index.html", error=None)


@app.post("/create")
def create_room():
    """Create a room and return its 8-character code and shareable URL.

    An optional JSON body may preselect the settings:
    {"mode": "wild"|"classic", "length": "short"|"medium"|"full", "timer": "off"|"30s"|...}.
    Classic rooms seat 2 players, Wild rooms up to 16.
    Anything left out uses the default (Wild, medium, no timer). Either player can
    still change the settings inside the room until the first turn is played.
    """
    payload = request.get_json(silent=True)
    payload = payload if isinstance(payload, dict) else {}
    options = {}
    for key, allowed in (("mode", MODES), ("length", LENGTHS), ("timer", TIMERS)):
        value = payload.get(key)
        if value is None:
            continue
        if not isinstance(value, str) or value not in allowed:
            return jsonify(error=f"Unknown {key}. Use one of: " + ", ".join(allowed)), 400
        options[key] = value
    if payload.get("auto_expand") is not None:
        if not isinstance(payload["auto_expand"], bool):
            return jsonify(error="auto_expand must be true or false."), 400
        options["auto_expand"] = payload["auto_expand"]
    if payload.get("auto_check") is not None:
        if not isinstance(payload["auto_check"], bool):
            return jsonify(error="auto_check must be true or false."), 400
        options["auto_check"] = payload["auto_check"]
    if payload.get("expand_margin") is not None:
        try:
            check_expand_margin(payload["expand_margin"])
        except GameError as exc:
            return jsonify(error=str(exc)), 400
        options["expand_margin"] = payload["expand_margin"]
    # Player count is not a choice: Classic is always 2, Wild always takes up to 16 (the game starts when
    # the host presses "Start now" or the room is full; the bag grows at start if there are too many players).
    options["max_players"] = 2 if options.get("mode", DEFAULT_MODE) == "classic" else MAX_PLAYERS
    if payload.get("language") is not None:
        try:
            check_language(payload["language"])
        except (GameError, TypeError) as exc:
            return jsonify(error=str(exc)), 400
        options["language"] = payload["language"]
    try:
        room = REGISTRY.create(**options)
    except GameError as exc:
        # Settings were validated above, so what is left is the server being full.
        return jsonify(error=str(exc)), 503
    path = f"/join/{room.code}"
    return (
        jsonify(
            code=room.code,
            path=path,
            url=request.host_url.rstrip("/") + path,
            mode=room.mode,
            length=room.length,
            timer=room.timer,
            max_players=room.max_players,
            language=room.language,
        ),
        201,
    )


@app.get("/join/<code>")
def join_page(code):
    room = REGISTRY.get(code)
    if room is None:
        message = "That room was not found. It may have expired - ask for a new link or create a game."
        return render_template("index.html", error=message), 404
    return render_template("game.html", code=room.code, mode=room.mode, length=room.length, timer=room.timer, language=room.language)


@app.get("/api/room/<code>")
def room_info(code):
    """Lets the home page check whether a saved session is still worth rejoining."""
    room = REGISTRY.get(code)
    if room is None:
        return jsonify(exists=False)
    return jsonify(
        exists=True, status=room.status, players=len(room.players), max_players=room.max_players,
        mode=room.mode, length=room.length, timer=room.timer, language=room.language,
    )


@app.get("/healthz")
def healthz():
    return "ok", 200, {"Content-Type": "text/plain; charset=utf-8"}


# --------------------------------------------------------------------------
# State broadcasting
# --------------------------------------------------------------------------
def push_all(room):
    """Send every connected player the change since the last thing they received.

    Views differ per player (own rack vs. opponent rack count), so we emit to
    individual socket ids rather than to the whole socket.io room.  A player
    with no baseline gets a full snapshot ("state"); everyone else gets a
    patch ("state_diff") carrying the version it applies on top of.
    """
    for player in room.players:
        if not (player.connected and player.sid):
            continue
        view = room.view_for(player)
        if player.sent_view is None:
            socketio.emit(
                "state",
                {"version": room.version, "config": {**CONFIG, "languages": available_languages()}, "state": view},
                to=player.sid,
            )
        else:
            patch = diff_views(player.sent_view, view)
            if not patch:
                continue
            socketio.emit(
                "state_diff",
                {"base": player.sent_version, "version": room.version, "patch": patch},
                to=player.sid,
            )
        player.sent_view = view
        player.sent_version = room.version


# --------------------------------------------------------------------------
# Turn clock
# --------------------------------------------------------------------------
_clock_started = False


def _clock_loop():
    """Once a second, pass for any Classic player whose turn timer has run out (Wild timers only remind)."""
    while True:
        socketio.sleep(1)
        for room in REGISTRY.rooms():
            try:
                with room.lock:
                    if room.expire_turn():
                        room.touch()
                        push_all(room)
            except Exception:
                log.exception("Turn clock failed for room %s", room.code)


def ensure_clock():
    global _clock_started
    if not _clock_started:
        _clock_started = True
        socketio.start_background_task(_clock_loop)


# --------------------------------------------------------------------------
# Socket events
# --------------------------------------------------------------------------
@socketio.on("join")
def on_join(data=None):
    """Join a room, or rejoin it with a saved session token after a reconnect."""
    ensure_clock()
    data = data if isinstance(data, dict) else {}
    room = REGISTRY.get(data.get("room"))
    if room is None:
        return {"ok": False, "code": "no_room", "error": "That room no longer exists."}
    token = data.get("token") if isinstance(data.get("token"), str) else ""
    with room.lock:
        player = room.player_by_token(token) if token else None
        if player is None:
            try:
                player = room.add_player(data.get("name"))
            except GameError as exc:
                return {"ok": False, "code": "full", "error": str(exc)}
        # (Re)bind this socket to the player.  Dropping the old baseline forces
        # a fresh full snapshot, which is also how a client resynchronises.
        room.player_joined(player, request.sid)
        player.sent_view = None
        SESSIONS[request.sid] = (room.code, player.token)
        join_room(room.code)
        room.maybe_start()  # starts once the room has max_players players
        room.touch()
        push_all(room)
        return {"ok": True, "token": player.token, "seat": player.seat, "room": room.code}


@socketio.on("disconnect")
def on_disconnect(*_args):
    info = SESSIONS.pop(request.sid, None)
    if info is None:
        return
    room = REGISTRY.get(info[0])
    if room is None:
        return
    with room.lock:
        player = room.player_by_token(info[1])
        # A refresh rebinds the player to a new socket before the old one
        # disconnects; only mark them offline if this socket is still theirs.
        if player is not None and player.sid == request.sid:
            room.player_left(player)
            room.touch()
            push_all(room)


def game_action(event):
    """Register a socket event that acts on the sender's room and player.

    The wrapped function receives (room, player, data) and either returns a
    dict of extra ack fields or raises GameError.  After a successful action
    every player is sent the resulting state change; the sender additionally
    gets an acknowledgement {"ok": True, ...} or {"ok": False, "error": ...}.
    """

    def decorator(fn):
        @wraps(fn)
        def handler(data=None):
            info = SESSIONS.get(request.sid)
            room = REGISTRY.get(info[0]) if info else None
            if room is None:
                return {"ok": False, "code": "no_session", "error": "You are not in a game. Reload the page."}
            with room.lock:
                player = room.player_by_token(info[1])
                if player is None:
                    return {"ok": False, "code": "no_session", "error": "You are not in a game. Reload the page."}
                try:
                    extra = fn(room, player, data if isinstance(data, dict) else {})
                except GameError as exc:
                    return {"ok": False, "error": str(exc)}
                except Exception:  # never leave the client's callback hanging
                    log.exception("Unhandled error in %s", event)
                    return {"ok": False, "error": "Server error. Please try again."}
                room.touch()
                push_all(room)
            return {"ok": True, **(extra or {})}

        return socketio.on(event)(handler)

    return decorator


@game_action("update_settings")
def on_update_settings(room, player, data):
    """Change game settings: {"mode": "wild"|"classic", "length": "short"|"medium"|"full", "timer": "off"|"30s"|...,
    "auto_expand": bool, "auto_check": bool, "expand_margin": 1-10, "max_players": 2-16 (wild only, before the game starts),
    "language": "en"|"fi"|"fr"|"es"|"sv" (only those with a word list installed)}.

    Either player may do this, but only before the first turn has been played.
    """
    room.update_settings(
        player,
        mode=data.get("mode"),
        length=data.get("length"),
        timer=data.get("timer"),
        auto_expand=data.get("auto_expand"),
        expand_margin=data.get("expand_margin"),
        max_players=data.get("max_players"),
        language=data.get("language"),
        auto_check=data.get("auto_check"),
    )
    return {
        "mode": room.mode, "length": room.length, "timer": room.timer,
        "auto_expand": room.auto_expand, "expand_margin": room.expand_margin,
        "max_players": room.max_players, "language": room.language,
        "auto_check": room.auto_check,
    }


@game_action("start_game")
def on_start_game(room, player, data):
    """Host starts the game before the room is full (needs at least two players)."""
    room.start_now(player)


@game_action("skip_player")
def on_skip_player(room, player, data):
    """Pass for a player who has been offline for a while: {"seat": n}."""
    seat = data.get("seat")
    if not isinstance(seat, int) or isinstance(seat, bool):
        raise GameError("Choose a player to skip.")
    return room.skip_player(player, seat)


@game_action("resign")
def on_resign(room, player, data):
    """Give up the game. Two players: the opponent wins. More: the game goes on without you."""
    return room.resign(player)


@game_action("pause_timer")
def on_pause_timer(room, player, data):
    """Freeze the turn timer (Wild only, any player)."""
    return room.pause_timer(player)


@game_action("resume_timer")
def on_resume_timer(room, player, data):
    """Let a paused turn timer run again (Wild only, any player)."""
    return room.resume_timer(player)


@game_action("skip_overtime")
def on_skip_overtime(room, player, data):
    """The host skips the player on turn once their timer has run out (Wild only)."""
    return room.skip_overtime(player)


@game_action("place_tiles")
def on_place_tiles(room, player, data):
    """Replace the player's tentative placement: {"placements": [{rack_index, row, col, letter?}]}."""
    room.place_tiles(player, data.get("placements"))


@game_action("stage_tiles")
def on_stage_tiles(room, player, data):
    """Prepare a word while the opponent is on turn: {"placements": [{rack_index, row, col, letter?}]}.

    Private to the sender; it becomes their tentative placement when their turn starts.
    """
    room.stage_tiles(player, data.get("placements"))


@game_action("submit_word")
def on_submit_word(room, player, data):
    """Commit the tentative placement: validate, score, draw tiles, pass the turn."""
    return room.submit(player)


@game_action("pass")
def on_pass(room, player, data):
    return room.pass_turn(player)


@game_action("swap_tiles")
def on_swap_tiles(room, player, data):
    """Exchange tiles with the bag: {"indices": [rack indices]}."""
    return room.swap(player, data.get("indices"))


@game_action("challenge_skip")
def on_challenge_skip(room, player, data):
    """Challenge the opponent's last play (Classic mode only).

    A failed challenge costs the challenger their turn - hence "skip".
    """
    return room.challenge(player)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    host = os.environ.get("HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", "5000"))
    extra = {"allow_unsafe_werkzeug": True} if ASYNC_MODE == "threading" else {}
    print(f"Scrabble server ({ASYNC_MODE} mode) on http://{host}:{port}")
    socketio.run(app, host=host, port=port, debug=os.environ.get("FLASK_DEBUG") == "1", **extra)


# --------------------------------------------------------------------------
# TODO - ideas for future versions (deliberately out of scope for v1)
# --------------------------------------------------------------------------
# TODO: Persist rooms (SQLite/Redis) so games survive restarts and so more than
#       one gunicorn worker can be used (needs a Socket.IO message queue too).
# TODO: Accounts / auth instead of anonymous per-room session tokens.
# TODO: In-game chat and emoji reactions.
# TODO: AI opponent (anchor-square move generator over a DAWG/GADDAG).
# TODO: Swap in the full official dictionary (TWL/NWL or SOWPODS/Collins) and
#       let the room creator choose it.
# TODO: Automatic forfeits for abandoned games (turn timers already pass for you).
# TODO: Rematch button, spectators, and a downloadable move log (GCG format).
# TODO: Rate-limit socket events and room creation per IP.
# TODO: Serve socket.io-client from /static instead of the CDN for offline use.
# TODO: Frontend tests (Playwright) and a Socket.IO integration test suite.
